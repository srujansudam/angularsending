import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AutopaymentComponent } from './autopayment/autopayment.component';
import { CreditcardComponent } from './creditcard/creditcard.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { WelcomeComponent } from './welcome/welcome.component';
import { LoginComponent } from './login/login.component';
import {ViewBenComponent} from './view-ben/view-ben.component';
import{BenSameComponent} from './ben-same/ben-same.component';
import{BenOtherComponent} from './ben-other/ben-other.component';
import { from } from 'rxjs';
import { CreditRequestsComponent } from './credit-requests/credit-requests.component';
import { BenRequestsComponent } from './ben-requests/ben-requests.component';
import { HistoryComponent } from './history/history.component';
import { BankerWelcomeComponent } from './banker-welcome/banker-welcome.component';
import { ErrorComponentComponent } from './error-component/error-component.component';


const routes: Routes = [
  {path:'',component:DashboardComponent,pathMatch:'full'},
  {path:'creditcard',component:CreditcardComponent},
  {path:'autopayment',component:AutopaymentComponent},
  {path:'welcome',component:WelcomeComponent},
  {path:'login',component:LoginComponent},
  {path:'banker-welcome',component:BankerWelcomeComponent},
  {path: 'viewben', component: ViewBenComponent},
  {path: 'bensame', component:BenSameComponent},
  {path: 'benother', component: BenOtherComponent},
  {path: 'creditrequests', component:CreditRequestsComponent},
  {path: 'benrequests', component:BenRequestsComponent},
  {path: 'history', component:HistoryComponent},
  {path:'error',component:ErrorComponentComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
