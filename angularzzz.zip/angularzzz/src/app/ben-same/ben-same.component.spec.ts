import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BenSameComponent } from './ben-same.component';

describe('BenSameComponent', () => {
  let component: BenSameComponent;
  let fixture: ComponentFixture<BenSameComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BenSameComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BenSameComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
