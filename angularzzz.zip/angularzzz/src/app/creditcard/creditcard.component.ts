import { Component, OnInit } from '@angular/core';
import { CreditCard } from '../model/creditcard';
import { CreditCardService } from '../service/creditcard.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-creditcard',
  templateUrl: './creditcard.component.html',
  styleUrls: ['./creditcard.component.css']
})
export class CreditcardComponent implements OnInit {

  newCard: CreditCard;
  cards: CreditCard[];
  cardNumber: number;
  expiryDate: string;
  errorMessage: string;
  boolean: boolean;


  constructor(private cardService: CreditCardService, private router: Router) {
    this.errorMessage = "";
    this.cards = [];
    this.newCard = new CreditCard();
    this.cardNumber = null;
    this.expiryDate = (new Date).toISOString().substr(0, 10);
    this.boolean = false;
  }

  ngOnInit() {
    this.load();
  }

  load() {
    this.cardService.viewall().subscribe(
      (data) => {
        this.cards = data;
      },
      (error) => {
        this.errorMessage = error;
        // this.router.navigate(['/error']);
      }
    );

  }

  addCard() {

    this.newCard.dateOfExpiry = new Date(this.expiryDate);

    if ((this.newCard.cardNumber) != (this.cardNumber)) {
      alert("card numbers do not match");
    } else {
      confirm("Are you sure you want to submit?");
    }
    this.cardNumber = null;

    this.cardService.addcard(this.newCard
    ).subscribe(
      (data) => {
        this.newCard = new CreditCard();
        this.load();
        this.boolean=false;

      },
      (error) => {
        this.errorMessage = error;
        alert(this.errorMessage);
        // this.router.navigate(['/error']);
      }
    );



  }
  deleteCard(cardNumber: number) {
    this.cardService.deletecard(cardNumber).subscribe(
      () => {
        this.load();
      }
    );

  }

}
