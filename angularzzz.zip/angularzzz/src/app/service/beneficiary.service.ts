import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { Beneficiary } from '../model/beneficiary';
import { Customer } from '../model/customer';
import { Message } from '../model/Message';
import { LoginService } from './login.service';
import { CreditCardService } from './creditcard.service';
import { catchError } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class BeneficiaryService {

  uci: number;
  baseUrl: string
  baseUrl2: string
  baseUrl3: string

  constructor(private http: HttpClient, private loginService:LoginService, private creditsrv :CreditCardService) {
    this.uci = this.loginService.customer.uci;
    this.baseUrl = `${environment.baseMwUrl}/beneficiary/${this.uci}`;
    this.baseUrl2 = `${environment.baseMwUrl}/beneficiary/${this.uci}/otherbank`;
    this.baseUrl3 = `${environment.baseMwUrl}/beneficiary/modifyinother`;
  }

  getAll(): Observable<Beneficiary[]> {
    return this.http.get<Beneficiary[]>(this.baseUrl).pipe(catchError(this.creditsrv.errorHandler));
  }

  addBeneficiary(beneficiary: Beneficiary): Observable<Beneficiary> {
    return this.http.post<Beneficiary>(this.baseUrl, beneficiary).pipe(catchError(this.creditsrv.errorHandler));
  }

  addBenOther(beneficiary: Beneficiary): Observable<Beneficiary> {
    return this.http.post<Beneficiary>(this.baseUrl2, beneficiary).pipe(catchError(this.creditsrv.errorHandler));
  }

  deleteBen(accountNumber: number): Observable<any> {
    return this.http.delete<any>(`${this.baseUrl}/${accountNumber}`)
  }

  updateBen(accountNumber: number, beneficiary: Beneficiary): Observable<Beneficiary> {
    return this.http.put<Beneficiary>(`${this.baseUrl}/${accountNumber}`, beneficiary).pipe(catchError(this.creditsrv.errorHandler));
  }

  updateBenOther(accountNumber: number, beneficiary: Beneficiary): Observable<Beneficiary> {
    return this.http.put<Beneficiary>(`${this.baseUrl3}/${accountNumber}`, beneficiary).pipe(catchError(this.creditsrv.errorHandler));
  }

}