import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable, throwError } from 'rxjs';
import { catchError, map } from 'rxjs/operators';
import { environment } from 'src/environments/environment';
import { Banker } from '../model/banker';
import { Customer } from '../model/customer';
import { Login } from '../model/login';
import { Message } from '../model/Message';
import { CreditCardService } from './creditcard.service';

@Injectable({
  providedIn: 'root'
})
export class LoginService {

  checkRole:Login;
  baseUrl: string;
  baseUrl1:string;
  customer: Customer;
  banker:Banker;
  private currentUserSubject: BehaviorSubject<Login>;
  public currentUser: Observable<Login>;
  errorMessage: string;

  constructor(private http: HttpClient) {
    this.currentUserSubject = new BehaviorSubject<Login>(JSON.parse(localStorage.getItem('currentUser')));
    this.currentUser = this.currentUserSubject.asObservable();
    this.baseUrl = `${environment.baseMwUrl}/login`;
    this.baseUrl1 = `${environment.baseMwUrl}/banklogin`;
  }

  public get currentUserValue(): Login {
    return this.currentUserSubject.value;
}

  login(userId: string): Observable<Message> {
    return this.http.get<Message>(`${this.baseUrl}/${userId}`)
    .pipe(map(user => {
        // login successful if there's a jwt token in the response
        if (user) {
            // store user details and jwt token in local storage to keep user logged in between page refreshes
            this.checkRole.role = "CUSTOMER";
            this.checkRole.userId = user.customer.userId;
            localStorage.setItem('currentUser', JSON.stringify(this.checkRole));
            this.currentUserSubject.next(this.checkRole);

        }

        return user;
    }),
      catchError(this.errorHandler)
    );
  }

  bankerlogin(userId: string): Observable<Message> {
    return this.http.get<Message>(`${this.baseUrl1}/${userId}`)
    .pipe(map(user => {
        // login successful if there's a jwt token in the response
        if (user) {
            // store user details and jwt token in local storage to keep user logged in between page refreshes
            this.checkRole.role = "BANKER";
            this.checkRole.userId = user.banker.userId;
            localStorage.setItem('currentUser', JSON.stringify(this.checkRole));
            this.currentUserSubject.next(this.checkRole);
        }
        return user;
    }),
      catchError(this.errorHandler)
    );
  }
    logout() {
        // remove user from local storage to log user out
        localStorage.removeItem('currentUser');
        this.currentUserSubject.next(null);
    }


    errorHandler(error: HttpErrorResponse) {
      if (error.error instanceof ErrorEvent) {
          console.error('An error occurred:', error.error);
      } else {

          this.errorMessage = error.error;
          console.error(
              `Backend returned code ${error.status}, ` +
              `body was: ${error.error}`);
      }
      
      return throwError(error.error);
  }
}




