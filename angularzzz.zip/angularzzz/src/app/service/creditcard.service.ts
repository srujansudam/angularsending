import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { environment } from 'src/environments/environment.prod';
import { Observable, throwError } from 'rxjs';
import { CreditCard } from '../model/creditcard';
import { Message } from '../model/Message';
import { Customer } from '../model/customer';
import { LoginService } from './login.service';
import { catchError } from 'rxjs/operators';

@Injectable({
    providedIn: 'root'
})

export class CreditCardService {
    baseUrl: string;
    message: Message;
    customer: Customer;
    uci: number;
    errorMessage: string;

    constructor(private http: HttpClient, private loginService: LoginService) {
        this.uci = this.loginService.customer.uci
        this.baseUrl = `${environment.baseMwUrl}/creditCard/${this.uci}`;
        this.errorMessage = "Something went wrong";
    }

    viewall(): Observable<CreditCard[]> {
        return this.http.get<CreditCard[]>(this.baseUrl).pipe(catchError(this.errorHandler));
    }
    addcard(card: CreditCard): Observable<CreditCard> {
        return this.http.post<CreditCard>(this.baseUrl, card).pipe(catchError(this.errorHandler));
    }
    deletecard(cardNumber: number): Observable<any> {
        return this.http.delete<any>(`${this.baseUrl}/${cardNumber}`);
    }
    errorHandler(error: HttpErrorResponse) {
        if (error.error instanceof ErrorEvent) {
            console.error('An error occurred:', error.error);
        } else {

            this.errorMessage = error.error;
            console.error(
                `Backend returned code ${error.status}, ` +
                `body was: ${error.error}`);
        }
        
        return throwError(error.error);
    }
}