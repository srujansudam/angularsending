import { Injectable } from '@angular/core';

import { environment } from 'src/environments/environment';
import { Account_ServiceProviders } from '../model/account_serviceProviders';
import { Observable } from 'rxjs';
import { AutoPayment } from '../model/autopayment';
import { HttpClient } from '@angular/common/http';
import { Customer } from '../model/customer';
import { Message } from '@angular/compiler/src/i18n/i18n_ast';
import { LoginService } from './login.service';
import { CreditCardService } from './creditcard.service';
import { catchError } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class AutoPaymentService {
  baseUrl: string;
  baseUrl1: string;
  message: Message;
  customer: Customer;
  uci: number;
  accNumber:number;
  errorMessage: string;
  baseUrl2: string;

  constructor(private http: HttpClient, private loginService:LoginService,private creditsrv :CreditCardService) {
    this.uci = this.loginService.customer.uci;
    this.baseUrl = `${environment.baseMwUrl}/autoPayment/${this.uci}`;
    this.baseUrl1 = `${this.baseUrl}/accountServiceProviders`;

   }


  showAccounts(): Observable<Account_ServiceProviders> {
    return this.http.get<Account_ServiceProviders>(this.baseUrl1).pipe(catchError(this.creditsrv.errorHandler));
  }

  viewAutopayments(): Observable<AutoPayment[]> {
    return this.http.get<AutoPayment[]>(this.baseUrl).pipe(catchError(this.creditsrv.errorHandler));
  }

  addAutopayment(autopayment: AutoPayment): Observable<AutoPayment> {
    return this.http.post<AutoPayment>(`${this.baseUrl}/${this.accNumber}`, autopayment).pipe(catchError(this.creditsrv.errorHandler));
  }

  modifyAutopayment(autopayment: AutoPayment): Observable<AutoPayment> {
    return this.http.post<AutoPayment>(this.baseUrl, autopayment).pipe(catchError(this.creditsrv.errorHandler));
  }

  deleteAutopayment(autopayment: AutoPayment): Observable<AutoPayment> {
    return this.http.post<AutoPayment>(this.baseUrl, autopayment).pipe(catchError(this.creditsrv.errorHandler));
  }
}
