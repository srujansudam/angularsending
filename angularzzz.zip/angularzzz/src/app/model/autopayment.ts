export class AutoPayment{
	public amount:number;
	public dateOfStart:string;
	public dateOfEnd:string;
	public serviceName:string ;
	public isEditing: boolean = false;
}