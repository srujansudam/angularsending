export class Customer{
    public uci:number;	
	public firstName:string ;	
	public lastName:string;	
	public userId: string;
}