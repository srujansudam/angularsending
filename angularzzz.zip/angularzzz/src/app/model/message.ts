import { Customer } from './customer';
import { Banker } from './banker';

export class Message{
    message:string;
    customer:Customer;
    banker:Banker;
}