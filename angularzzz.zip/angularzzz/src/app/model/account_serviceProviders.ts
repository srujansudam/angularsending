import { Account } from './account';
import { ServiceProvider } from './serviceprovider';

export class Account_ServiceProviders{
    public accounts: Account[];
	public serviceProviders:ServiceProvider[];
}