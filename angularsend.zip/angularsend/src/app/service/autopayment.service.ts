import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { Observable } from 'rxjs';
import { AutoPayment } from '../model/autopayment';


Injectable({
    providedIn: 'root'
  })

  export class AutopaymentService{
    baseUrl: string;
    baseUrl1: string;

    constructor(private http: HttpClient) {
        this.baseUrl = `${environment.baseMwUrl}/autoPayment`;
        this.baseUrl1 = `${this.baseUrl}`;

        // ${accountNumber}
      }
      showAccounts(): Observable<AutoPayment[]> {
        return this.http.get<AutoPayment[]>(this.baseUrl);
    }

      viewAutopayments(): Observable<AutoPayment[]> {
        return this.http.get<AutoPayment[]>(this.baseUrl);
    }
    
      addAutopayment(autopayment: AutoPayment): Observable<AutoPayment> {
        return this.http.post<AutoPayment>(this.baseUrl1, autopayment);
    }
    
    modifyAutopayment(autopayment: AutoPayment): Observable<AutoPayment> {
        return this.http.post<AutoPayment>(this.baseUrl, autopayment);
    }
    
    deleteAutopayment(autopayment: AutoPayment): Observable<AutoPayment> {
        return this.http.post<AutoPayment>(this.baseUrl, autopayment);
    }

  }