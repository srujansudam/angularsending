export class Login{
    public role:string;		
	public userId: string;
}