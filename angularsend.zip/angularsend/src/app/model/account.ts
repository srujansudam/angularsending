export class Account{
    public accNo:number;
	public balance:number;
}