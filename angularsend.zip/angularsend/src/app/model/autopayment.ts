export class AutoPayment{
	private amount:number;
	private dateOfStart:string;
	private dateOfEnd:string;
	private serviceName:string ;
}