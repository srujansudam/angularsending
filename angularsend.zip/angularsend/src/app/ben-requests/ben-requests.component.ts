import { Component, OnInit } from '@angular/core';
import { BankerService } from '../service/banker.service';
import { bankerHistory } from '../model/bankerhistory';
import { ActivatedRoute, Router } from '@angular/router';
import { Beneficiary } from '../model/beneficiary';
import { Banker } from '../model/banker';
import { LoginService } from '../service/login.service';

@Component({
  selector: 'app-ben-requests',
  templateUrl: './ben-requests.component.html',
  styleUrls: ['./ben-requests.component.css']
})
export class BenRequestsComponent implements OnInit {
benHistory: bankerHistory [];
beneficiaries: Beneficiary[];
banker: Banker;

  constructor(private bankerService: BankerService,private actRt: ActivatedRoute,
    private router: Router, private loginService:LoginService) {
    this.banker = this.loginService.banker;
    this.benHistory=[];
   }

  ngOnInit() {
    this.load();
  }

  load()
  {
    this.bankerService.benRequestsForMe(this.banker.bankerId).subscribe(
      (data) => {
      this.beneficiaries=data;
      }
    );
  }

  approve(accountNum : number){
   if(confirm("Press ok to confirm your decision as approve")){
     this.bankerService.approveOrDisapproveBeneficiaries(accountNum , 'Approve').subscribe(
     (data) => {

     }
     )

     }
   
  }
  
  disapprove(accountNum : number){
    if(confirm("Press ok to confirm your decision as approve")){
      this.bankerService.approveOrDisapproveBeneficiaries(accountNum , 'Disapprove').subscribe(
      (data) => {
        
      }
      )
 
      }
    
   }

}
