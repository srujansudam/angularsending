import { Component, OnInit } from '@angular/core';
import { Beneficiary } from '../model/beneficiary';
import { BeneficiaryService } from '../service/beneficiary.service';

@Component({
  selector: 'app-ben-other',
  templateUrl: './ben-other.component.html',
  styleUrls: ['./ben-other.component.css']
})
export class BenOtherComponent implements OnInit {
  newBen: Beneficiary;
  beneficiaries: Beneficiary[];
  accNumber: number;

  constructor(private benService: BeneficiaryService) {
    this.beneficiaries = [];
    this.newBen = new Beneficiary();
    this.accNumber = null;
  }

  ngOnInit() {

  }

  save() {
    if ((this.newBen.accountNumber) != (this.accNumber)) {
      alert("Account numbers do not match");
    } else {
      confirm("Are you sure you want to submit?");
    }
    this.accNumber = null;

    this.benService.addBenOther(this.newBen).subscribe(
      (data) => {
        this.newBen = new Beneficiary();

      }
    );

  }


}
