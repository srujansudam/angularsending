import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Login } from '../model/login';

import { LoginService } from '../service/login.service';
import { Message } from '../model/Message';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  checkRole: Login;
  message: Message;

  constructor(private loginService: LoginService, private actRt: ActivatedRoute,
    private router: Router) {
      this.checkRole = new Login();
      this.message = new Message();
  }

  ngOnInit() {
    
  }

  login() {
    this.loginService.checkRole = this.checkRole;
    if ((this.checkRole.role) == "CUSTOMER") {

      this.loginService.login(this.checkRole.userId).subscribe(
        (data) => {
           this.message = data;
          if (data.customer == null) {
            this.router.navigateByUrl('/creditcard');
          } else {
            this.loginService.customer = this.message.customer;
            this.router.navigateByUrl('/welcome');
          }
        }

      );
    }
    else {
      this.loginService.checkRole = this.checkRole; 
      this.loginService.bankerlogin(this.checkRole.userId).subscribe(
        (data) => {
          this.message = data;
          if (data.banker == null) {
            this.router.navigateByUrl('/exceptionlogin');
          } else {
            this.loginService.banker = this.message.banker;
            this.router.navigateByUrl('/banker-welcome');
          }
        }
         
      );
    }
  }
}










