import { Component, OnInit } from '@angular/core';
import { Login } from './model/login';
import { LoginService } from './service/login.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  checkRole: Login;
  goTO: string;

  constructor(private loginService: LoginService, private router: Router) {
    this.checkRole =JSON.parse(localStorage.getItem('currentUser'));
    this.goTO= "login"; 
   
  }

  ngOnInit() {
    
    console.log(this.checkRole);
    if (this.checkRole == null) {
      this.goTO = "login";
      console.log(this.goTO);
    } else if(this.checkRole.role == "CUSTOMER"){ 
      this.goTO = "welcome"; 
      console.log(this.goTO);
    } else {
      this.goTO = "banker-welcome";
      console.log(this.goTO);
    }
  }
  title = 'integrated-banking-system';

  
  logout(){
    this.loginService.logout();
    this.router.navigateByUrl("/login");
  }
}
