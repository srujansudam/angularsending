import { Component, OnInit } from '@angular/core';
import { AutoPayment } from '../model/autopayment';
import { AutopaymentService } from '../service/autopayment.service';

@Component({
  selector: 'app-autopayment',
  templateUrl: './autopayment.component.html',
  styleUrls: ['./autopayment.component.css']
})
export class AutopaymentComponent implements OnInit {

  newAutopayment: AutoPayment;
  autopayments: AutoPayment[];
  amount: number;
  dateOfStart: string;
  dateOfEnd: string;
  serviceName: string;


  constructor(private autopaymentService: AutopaymentService) {
    this.autopayments = [];
    this.newAutopayment = new AutoPayment();
    this.amount = null;
    this.dateOfStart = (new Date).toISOString().substr(0, 10);
    this.dateOfEnd = (new Date).toISOString().substr(0, 10);
    this.serviceName = null;
  }

  ngOnInit() {
    this.load();
  }

  load() {
    this.autopaymentService.viewAutopayments().subscribe(
      (data) => {
        this.autopayments = data;
      }
    );
    }

    add(){

    }
  }