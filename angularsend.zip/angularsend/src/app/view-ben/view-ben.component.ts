import { Component, OnInit } from '@angular/core';
import { BeneficiaryService } from '../service/beneficiary.service';
import { Beneficiary } from '../model/beneficiary';

@Component({
  selector: 'app-view-ben',
  templateUrl: './view-ben.component.html',
  styleUrls: ['./view-ben.component.css']
})
export class ViewBenComponent implements OnInit {
  beneficiaries: Beneficiary[];

  constructor(private benService: BeneficiaryService) { }
  ngOnInit() {
    this.load();
  }

  load() {
    this.benService.getAll().subscribe(
      (data) => {
        this.beneficiaries = data;
      }
    );
  }

  edit(ben: Beneficiary) {
    ben.isEditing = true;
  }

  cancelEdit(ben: Beneficiary) {
    ben.isEditing = false;
  }
  delete(accNumber: number) {
    if (confirm("you sure?? think again before deleting!")) {
      this.benService.deleteBen(accNumber).subscribe(
        () => {
          this.load();
        }
      );
    }
  }

  
  save(ben: Beneficiary) {
    if (ben.type == "MY_ACCOUNT_IN_IBS" || ben.type == "OTHERS_ACCOUNT_IN_IBS") {
      this.benService.updateBen(ben.accountNumber, ben).subscribe(
        (data) => {
          this.load();
        }
      );
    }
    else {
      this.benService.updateBenOther(ben.accountNumber, ben).subscribe(
        (data) => {
          this.load();
        }
      );
    }
  }
}
